Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic

$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigPath=Join-Path $Root "nyx_launcher_config.json"
$PresetsPath=Join-Path $Root "nyx_minimap_presets.json"
$SettingsPath=Join-Path $Root "nyx_minimap_settings.json"
$ApplyScript=Join-Path $Root "Apply_Selected_Minimap_Preset.ps1"

function ReadJson($Path,$Fallback){
    if(!(Test-Path $Path)){
        $Fallback|ConvertTo-Json -Depth 20|Set-Content -LiteralPath $Path -Encoding UTF8
    }
    try{return Get-Content $Path -Raw|ConvertFrom-Json}
    catch{
        $Fallback|ConvertTo-Json -Depth 20|Set-Content -LiteralPath $Path -Encoding UTF8
        return Get-Content $Path -Raw|ConvertFrom-Json
    }
}

function FindPythonStatus(){
    $Checks=@(
        @{Name="py";Args=@("-3")},
        @{Name="python";Args=@()},
        @{Name="python3";Args=@()}
    )
    foreach($Check in $Checks){
        $Cmd=Get-Command $Check.Name -ErrorAction SilentlyContinue
        if(!$Cmd){continue}
        $Exe=$Cmd.Source
        if(!$Exe){$Exe=$Cmd.Path}
        if(!$Exe){$Exe=$Check.Name}
        try{
            $Output=& $Exe @($Check.Args) --version 2>&1
            $Text=($Output|Out-String).Trim()
            if($LASTEXITCODE -eq 0 -and $Text -match "Python\s+3\."){return $Text}
        }catch{}
    }
    return ""
}

function FindGameAuto(){
    $Candidates=@(
        "C:\Games\Minecraft Dungeons\Dungeons\Binaries\Win64\Dungeons-Win64-Shipping.exe",
        "C:\Program Files (x86)\Steam\steamapps\common\MinecraftDungeons\Dungeons\Binaries\Win64\Dungeons-Win64-Shipping.exe",
        "C:\Program Files (x86)\Steam\steamapps\common\Minecraft Dungeons\Dungeons\Binaries\Win64\Dungeons-Win64-Shipping.exe",
        "C:\XboxGames\Minecraft Dungeons\Dungeons\Binaries\Win64\Dungeons-Win64-Shipping.exe"
    )
    foreach($Item in $Candidates){if(Test-Path $Item){return $Item}}
    foreach($RootPath in @("C:\Games","C:\XboxGames","C:\Program Files (x86)\Steam\steamapps\common")){
        if(Test-Path $RootPath){
            $Hit=Get-ChildItem $RootPath -Recurse -File -Filter "Dungeons-Win64-Shipping.exe" -ErrorAction SilentlyContinue|Select-Object -First 1
            if($Hit){return $Hit.FullName}
        }
    }
    return ""
}
function GetPreset($Name){
    foreach($Prop in $PresetsObj.PSObject.Properties){
        if($Prop.Name -eq $Name){return $Prop.Value}
    }
    return $null
}
function SetPreset($Name){
    $P=GetPreset $Name
    if($null -eq $P){return}
    $Ground.Value=[decimal]$P.GroundOpacity
    $Outline.Value=[decimal]$P.OutlineOpacity
    $Border.Value=[decimal]$P.Width
    $Scale.Value=[decimal]$P.MapScale
$Preview.Invalidate()
}
function SaveConfig(){
    ([ordered]@{
        GameExe=$Game.Text
        UAssetGUI=$UAsset.Text
        SelectedPreset=[string]$Preset.SelectedItem
        VersionHint=[string]$Version.SelectedItem
        AuthorCredit="Nyx"
    })|ConvertTo-Json|Set-Content -LiteralPath $ConfigPath -Encoding UTF8
}
function SaveSettings(){
    ([ordered]@{
        GroundOpacity=[double]$Ground.Value
        OutlineOpacity=[double]$Outline.Value
        Width=[double]$Border.Value
        RefractionDepthBias=0.0
        MapScale=[double]$Scale.Value
        MapAspectScaleX=1.0
        MapAspectScaleY=1.0
    })|ConvertTo-Json|Set-Content -LiteralPath $SettingsPath -Encoding UTF8
}
function Label($Text,[int]$X,[int]$Y,[int]$W=160){
    $L=New-Object Windows.Forms.Label
    $L.Text=$Text
    $L.Location=New-Object Drawing.Point($X,$Y)
    $L.Size=New-Object Drawing.Size($W,24)
    $L.ForeColor=[Drawing.Color]::FromArgb(226,232,242)
    $null=$Form.Controls.Add($L)
}
function BoxStyle($Box){
    $Box.BackColor=[Drawing.Color]::FromArgb(31,34,42)
    $Box.ForeColor=[Drawing.Color]::White
    $Box.BorderStyle=[Windows.Forms.BorderStyle]::FixedSingle
}
function NumberInput($Text,[int]$X,[int]$Y,[decimal]$Min,[decimal]$Max,[decimal]$Inc,[decimal]$Val){
    Label $Text $X $Y 270
    $N=New-Object Windows.Forms.NumericUpDown
    $N.DecimalPlaces=4
    $N.Minimum=$Min
    $N.Maximum=$Max
    $N.Increment=$Inc
    $N.Value=$Val
    $N.Location=New-Object Drawing.Point(($X+310),$Y)
    $N.Size=New-Object Drawing.Size(120,28)
    $N.BackColor=[Drawing.Color]::FromArgb(31,34,42)
    $N.ForeColor=[Drawing.Color]::White
    $N.Add_ValueChanged({$Preview.Invalidate()})
    $null=$Form.Controls.Add($N)
    return $N
}
function Button($Text,[int]$X,[int]$Y,[int]$W,[scriptblock]$Click){
    $B=New-Object Windows.Forms.Button
    $B.Text=$Text
    $B.Location=New-Object Drawing.Point($X,$Y)
    $B.Size=New-Object Drawing.Size($W,32)
    $B.Add_Click($Click)
    $null=$Form.Controls.Add($B)
    return $B
}

$Cfg=ReadJson $ConfigPath ([ordered]@{GameExe="C:\Games\Minecraft Dungeons\Dungeons\Binaries\Win64\Dungeons-Win64-Shipping.exe";UAssetGUI="C:\Users\Cesar\Downloads\UGUI\UAssetGUI.exe";SelectedPreset="Max Range";VersionHint="Auto";AuthorCredit="Nyx"})
$PresetsObj=ReadJson $PresetsPath ([ordered]@{"Max Range"=[ordered]@{GroundOpacity=.96;OutlineOpacity=1.40;Width=1.55;RefractionDepthBias=0;MapScale=.35;MapAspectScaleX=1;MapAspectScaleY=1}})

$Form=New-Object Windows.Forms.Form
$Form.Text="NYX Minimap Modder"
$Form.Size=New-Object Drawing.Size(1320,790)
$Form.AutoScaleMode=[Windows.Forms.AutoScaleMode]::None
$Form.MinimumSize=New-Object Drawing.Size(1320,790)
$Form.StartPosition="CenterScreen"
$Form.BackColor=[Drawing.Color]::FromArgb(14,15,19)
$Form.ForeColor=[Drawing.Color]::White
$Form.Font=New-Object Drawing.Font("Segoe UI",10)

$Title=New-Object Windows.Forms.Label
$Title.Text="NYX Minimap Modder"
$Title.Font=New-Object Drawing.Font("Segoe UI",20,[Drawing.FontStyle]::Bold)
$Title.Location=New-Object Drawing.Point(24,18)
$Title.Size=New-Object Drawing.Size(520,42)
$Title.ForeColor=[Drawing.Color]::FromArgb(245,250,255)
$null=$Form.Controls.Add($Title)

$Credit=New-Object Windows.Forms.Label
$Credit.Text="Credits: Nyx"
$Credit.Font=New-Object Drawing.Font("Segoe UI",11,[Drawing.FontStyle]::Bold)
$Credit.Location=New-Object Drawing.Point(1120,26)
$Credit.Size=New-Object Drawing.Size(150,25)
$Credit.ForeColor=[Drawing.Color]::FromArgb(80,220,255)
$null=$Form.Controls.Add($Credit)

Label "Game version" 32 78 170
$Version=New-Object Windows.Forms.ComboBox
$Version.Location=New-Object Drawing.Point(220,76)
$Version.Size=New-Object Drawing.Size(260,28)
$Version.DropDownStyle=[Windows.Forms.ComboBoxStyle]::DropDownList
$null=$Version.Items.AddRange([object[]]@("Auto","Launcher / Standalone","Steam","Microsoft Store / Xbox","Repacked / Portable"))
if($Version.Items.Contains([string]$Cfg.VersionHint)){$Version.SelectedItem=[string]$Cfg.VersionHint}else{$Version.SelectedIndex=0}
$null=$Form.Controls.Add($Version)

Label "Game exe" 32 116 170
$Game=New-Object Windows.Forms.TextBox
$Game.Location=New-Object Drawing.Point(220,114)
$Game.Size=New-Object Drawing.Size(795,28)
$Game.Text=[string]$Cfg.GameExe
BoxStyle $Game
$null=$Form.Controls.Add($Game)
Button "Browse" 1035 112 95 {
    $D=New-Object Windows.Forms.OpenFileDialog
    $D.Filter="Minecraft Dungeons exe|Dungeons-Win64-Shipping.exe;Dungeons.exe|Executable|*.exe|All files|*.*"
    if($D.ShowDialog() -eq [Windows.Forms.DialogResult]::OK){$Game.Text=$D.FileName}
}|Out-Null
Button "Auto Find" 1140 112 105 {
    $F=FindGameAuto
    if($F){$Game.Text=$F;$Status.Text="Found game executable."}
    else{[Windows.Forms.MessageBox]::Show("Could not auto-find the game. Browse to Dungeons-Win64-Shipping.exe or Dungeons.exe.","NYX")|Out-Null}
}|Out-Null

Label "UAssetGUI" 32 154 170
$UAsset=New-Object Windows.Forms.TextBox
$UAsset.Location=New-Object Drawing.Point(220,152)
$UAsset.Size=New-Object Drawing.Size(795,28)
$UAsset.Text=[string]$Cfg.UAssetGUI
BoxStyle $UAsset
$null=$Form.Controls.Add($UAsset)
Button "Browse" 1035 150 95 {
    $D=New-Object Windows.Forms.OpenFileDialog
    $D.Filter="UAssetGUI.exe|UAssetGUI.exe|Executable|*.exe|All files|*.*"
    if($D.ShowDialog() -eq [Windows.Forms.DialogResult]::OK){$UAsset.Text=$D.FileName}
}|Out-Null

Label "Preset" 32 210 170
$Preset=New-Object Windows.Forms.ComboBox
$Preset.Location=New-Object Drawing.Point(220,208)
$Preset.Size=New-Object Drawing.Size(285,28)
$Preset.DropDownStyle=[Windows.Forms.ComboBoxStyle]::DropDownList
foreach($Prop in $PresetsObj.PSObject.Properties){$null=$Preset.Items.Add($Prop.Name)}
if($Preset.Items.Count -gt 0){
    if($Preset.Items.Contains([string]$Cfg.SelectedPreset)){$Preset.SelectedItem=[string]$Cfg.SelectedPreset}else{$Preset.SelectedIndex=0}
}
$null=$Form.Controls.Add($Preset)

$Ground=NumberInput "Explored fill opacity" 32 254 0 2 0.05 0.96
$Outline=NumberInput "Untraveled / border opacity" 32 292 0 3 0.05 1.40
$Border=NumberInput "Border width" 32 330 0.10 8 0.10 1.55
$Scale=NumberInput "Map range, lower = farther" 32 368 0.001 100000 0.01 0.35


$Preview=New-Object Windows.Forms.Panel
$Preview.Location=New-Object Drawing.Point(635,208)
$Preview.Size=New-Object Drawing.Size(610,360)
$Preview.BackColor=[Drawing.Color]::FromArgb(7,8,10)
$null=$Form.Controls.Add($Preview)

$Preview.Add_Paint({
    param($Sender,$E)
    $G=$E.Graphics
    $G.SmoothingMode=[Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $G.Clear([Drawing.Color]::FromArgb(7,8,10))

    $PW=[int]$Sender.Width
    $PH=[int]$Sender.Height
    $G.DrawRectangle((New-Object Drawing.Pen([Drawing.Color]::FromArgb(70,115,125,140),1)),8,8,($PW-16),($PH-16))
    $Font=New-Object Drawing.Font("Segoe UI",9)
    $Bold=New-Object Drawing.Font("Segoe UI",9,[Drawing.FontStyle]::Bold)
    $TextBrush=New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(230,230,235))
    $G.DrawString("Approx preview. Actual dungeon layout comes from the level.",$Font,$TextBrush,24,18)

    $MapSize=230
    $X=36
    $Y=54
    $CX=[int]($X+($MapSize/2))
    $CY=[int]($Y+($MapSize/2))
    $GroundA=[int][Math]::Min(255,[Math]::Max(35,(65*[double]$Ground.Value)))
    $OutlineA=[int][Math]::Min(255,[Math]::Max(45,(125*[double]$Outline.Value)))
    $LineW=[float][Math]::Max(1.0,[double]$Border.Value)

    $Clip=New-Object Drawing.Drawing2D.GraphicsPath
    $Clip.AddEllipse($X,$Y,$MapSize,$MapSize)
    $OldClip=$G.Clip
    $G.SetClip($Clip)

    $G.FillEllipse((New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb($GroundA,56,66,74))),$X,$Y,$MapSize,$MapSize)

    $Tile=[int][Math]::Max(5,(7+([double]$Scale.Value*4)))
    $GridPen=New-Object Drawing.Pen([Drawing.Color]::FromArgb(48,145,155,165),1)
    for($GX=$X-30;$GX -lt ($X+$MapSize+40);$GX+=$Tile){$G.DrawLine($GridPen,$GX,$Y-30,$GX,($Y+$MapSize+30))}
    for($GY=$Y-30;$GY -lt ($Y+$MapSize+40);$GY+=$Tile){$G.DrawLine($GridPen,$X-30,$GY,($X+$MapSize+30),$GY)}

    $RoomShell=New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb($OutlineA,174,186,196))
    $RoomInner=New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(190,38,48,56))
    $Corr=New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(190,38,48,56))

    $Rooms=@(
        @(20,20,72,40),@(110,28,74,38),@(188,70,56,34),@(42,102,64,42),
        @(118,126,85,48),@(22,178,75,36),@(145,196,74,34),@(190,150,58,40)
    )
    foreach($R in $Rooms){
        $RX=[int]($X+$R[0]);$RY=[int]($Y+$R[1]);$RW=[int]$R[2];$RH=[int]$R[3]
        $G.FillRectangle($RoomShell,$RX,$RY,$RW,$RH)
        $G.FillRectangle($RoomInner,($RX+6),($RY+6),($RW-12),($RH-12))
    }
    $G.FillRectangle($Corr,($X+72),($Y+48),105,16)
    $G.FillRectangle($Corr,($X+128),($Y+62),16,110)
    $G.FillRectangle($Corr,($X+65),($Y+140),134,16)
    $G.FillRectangle($Corr,($X+92),($Y+188),120,16)

    $G.Clip=$OldClip

    $G.DrawEllipse((New-Object Drawing.Pen([Drawing.Color]::FromArgb([Math]::Min(255,($OutlineA+35)),230,240,248),$LineW)),$X,$Y,$MapSize,$MapSize)

    $Pts=New-Object 'System.Drawing.Point[]' 3
    $Pts[0]=New-Object Drawing.Point($CX,($CY-18))
    $Pts[1]=New-Object Drawing.Point(($CX-12),($CY+13))
    $Pts[2]=New-Object Drawing.Point(($CX+12),($CY+13))
    $G.FillPolygon((New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(245,0,235,255))),$Pts)
    $G.DrawPolygon((New-Object Drawing.Pen([Drawing.Color]::FromArgb(245,0,40,50),2)),$Pts)

    $G.DrawString(("MapScale {0:0.00} | lower = farther" -f [double]$Scale.Value),$Font,$TextBrush,24,306)
    $G.DrawString(("Border {0:0.00} | opacity {1:0.00}" -f [double]$Border.Value,[double]$Outline.Value),$Font,$TextBrush,24,326)
})

$Preset.Add_SelectedIndexChanged({SetPreset ([string]$Preset.SelectedItem)})

$Tips=New-Object Windows.Forms.TextBox
$Tips.Multiline=$true
$Tips.ReadOnly=$true
$Tips.ScrollBars=[Windows.Forms.ScrollBars]::Vertical
$Tips.Location=New-Object Drawing.Point(32,450)
$Tips.Size=New-Object Drawing.Size(555,105)
$Tips.BackColor=[Drawing.Color]::FromArgb(25,27,34)
$Tips.ForeColor=[Drawing.Color]::FromArgb(230,230,235)
$Tips.BorderStyle=[Windows.Forms.BorderStyle]::FixedSingle
$Tips.Text="Tips:`r`n- Lower MapScale = farther map range.`r`n- Use any positive MapScale value. Lower values show farther away.`r`n- UAssetGUI.exe, UnrealPak.exe, and Python 3 are required for Apply / Rebuild."
$null=$Form.Controls.Add($Tips)

$Status=New-Object Windows.Forms.Label
$Status.Text="Ready. Credits: Nyx"
$Status.Location=New-Object Drawing.Point(32,590)
$Status.Size=New-Object Drawing.Size(900,25)
$Status.ForeColor=[Drawing.Color]::FromArgb(120,220,255)
$null=$Form.Controls.Add($Status)

Button "Save Preset" 32 655 135 {
    $Name=[Microsoft.VisualBasic.Interaction]::InputBox("Preset name:","Save Preset","Custom")
    if(![string]::IsNullOrWhiteSpace($Name)){
        $All=ReadJson $PresetsPath ([ordered]@{})
        $New=[pscustomobject]@{GroundOpacity=[double]$Ground.Value;OutlineOpacity=[double]$Outline.Value;Width=[double]$Border.Value;RefractionDepthBias=0.0;MapScale=[double]$Scale.Value;MapAspectScaleX=1.0;MapAspectScaleY=1.0}
        $All|Add-Member -NotePropertyName $Name -NotePropertyValue $New -Force
        $All|ConvertTo-Json -Depth 20|Set-Content -LiteralPath $PresetsPath -Encoding UTF8
        if(!$Preset.Items.Contains($Name)){$null=$Preset.Items.Add($Name)}
        $Preset.SelectedItem=$Name
        $Status.Text="Saved preset: $Name"
    }
}|Out-Null

Button "Apply / Rebuild" 182 655 155 {
    if(!(Test-Path $Game.Text)){[Windows.Forms.MessageBox]::Show("Game exe not found. Browse to Dungeons-Win64-Shipping.exe or Dungeons.exe.","NYX")|Out-Null;return}
    if(!(Test-Path $UAsset.Text)){[Windows.Forms.MessageBox]::Show("UAssetGUI.exe not found. Browse to UAssetGUI.exe.","NYX")|Out-Null;return}
    $PythonStatus=FindPythonStatus
    if(!$PythonStatus){[Windows.Forms.MessageBox]::Show("Python 3 was not found. Install Python 3.10 or newer, enable Add python.exe to PATH, then reopen this launcher. Steam users still need Python because the builder uses Python patch scripts.","NYX Minimap - Missing Python")|Out-Null;return}
    SaveConfig
    SaveSettings
    $Args="-NoExit -ExecutionPolicy Bypass -File `"$ApplyScript`" -GameExe `"$($Game.Text)`" -UAssetGUI `"$($UAsset.Text)`" -Settings `"$SettingsPath`""
    Start-Process "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList $Args -WorkingDirectory $Root
    $Status.Text="Started rebuild PowerShell."
}|Out-Null

Button "Launch Game" 352 655 125 {
    if(Test-Path $Game.Text){Start-Process $Game.Text}else{$Status.Text="Game exe not found."}
}|Out-Null

Button "Auto Find" 492 655 115 {
    $F=FindGameAuto
    if($F){$Game.Text=$F;$Status.Text="Found game executable."}else{$Status.Text="Could not auto-find. Use Browse."}
}|Out-Null

Button "Open Pak Folder" 622 655 140 {
    if(Test-Path $Game.Text){
        $Win=Split-Path $Game.Text -Parent
        $Pak=Join-Path (Split-Path (Split-Path $Win -Parent) -Parent) "Content\Paks"
        if(Test-Path $Pak){Start-Process explorer.exe $Pak}
    }
}|Out-Null

Button "Remove Mod" 782 655 130 {
    $Confirm=[Windows.Forms.MessageBox]::Show("Remove installed NYX minimap files from the game Pak folder?", "Remove NYX Minimap", [Windows.Forms.MessageBoxButtons]::YesNo, [Windows.Forms.MessageBoxIcon]::Question)
    if($Confirm -eq [Windows.Forms.DialogResult]::Yes){
        SaveConfig
        $RemoveScript=Join-Path $Root "Remove_NYX_Minimap.ps1"
        $Args="-NoExit -ExecutionPolicy Bypass -File `"$RemoveScript`""
        Start-Process "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList $Args -WorkingDirectory $Root
        $Status.Text="Started remove mod PowerShell."
    }
}|Out-Null

if($Preset.SelectedItem){SetPreset ([string]$Preset.SelectedItem)}
$Form.Add_Shown({
    $Game.SelectionStart=0; $Game.SelectionLength=0
    $UAsset.SelectionStart=0; $UAsset.SelectionLength=0
})
$null=$Form.ShowDialog()

. "$PSScriptRoot\NYX_Minimap_Common.ps1"

$paths = Get-GamePaths
Stop-Dungeons
Remove-OldNYXPaks $paths.PakDir
Disable-NYXRuntime $paths.ModsTxt

Write-Host ""
Write-Host "DONE. Removed all NYX paks and disabled runtime." -ForegroundColor Green
pause

import json
import sys
import pathlib
import traceback

src = pathlib.Path(sys.argv[1])
dst = pathlib.Path(sys.argv[2])
log = dst.with_suffix(".patch_report.txt")

changes = []
targets = []

TARGET_NAMES = (
    "LocalArrow",
    "LocalArrowDamage",
    "LocalArrowShadow",
    "UMG_PlayerMapArrow",
    "LocalPlayerMarker",
    "PhysicalArrowOffset"
)

def props(e):
    return [p for p in e.get("Data", []) if isinstance(p, dict) and "Name" in p]

def prop(e, name):
    for p in props(e):
        if p.get("Name") == name:
            return p
    return None

def export_name(e):
    return str(e.get("ObjectName") or e.get("Name") or "")

def is_target(e):
    n = export_name(e)
    t = str(e.get("$type") or e.get("Type") or e.get("Class") or "")
    return any(x in n for x in TARGET_NAMES) or ("DungeonsImage" in t and "Arrow" in n)

def set_enum_prop(e, name, value, label):
    p = prop(e, name)
    if p and "EnumPropertyData" in str(p.get("$type")):
        old = p.get("Value")
        p["Value"] = value
        changes.append(f"{label}: {name} {old} -> {value}")
        return True

    simple_props = e.get("Properties")
    if isinstance(simple_props, dict) and name in simple_props:
        old = simple_props.get(name)
        simple_props[name] = value
        changes.append(f"{label}: Properties.{name} {old} -> {value}")
        return True
    return False

def set_float_prop(e, name, value, label):
    p = prop(e, name)
    if p and "FloatPropertyData" in str(p.get("$type")):
        old = p.get("Value")
        p["Value"] = float(value)
        changes.append(f"{label}: {name} {old} -> {value}")
        return True

    simple_props = e.get("Properties")
    if isinstance(simple_props, dict) and isinstance(simple_props.get(name), (int, float)):
        old = simple_props.get(name)
        simple_props[name] = float(value)
        changes.append(f"{label}: Properties.{name} {old} -> {value}")
        return True
    return False

def set_linear_alpha(e, name, alpha, label):
    p = prop(e, name)
    if p:
        def rec(v):
            if isinstance(v, dict):
                if isinstance(v.get("Value"), dict) and "A" in v["Value"]:
                    old = v["Value"].get("A")
                    v["Value"]["A"] = float(alpha)
                    changes.append(f"{label}: {name}.A {old} -> {alpha}")
                    return True
                for vv in v.values():
                    if rec(vv):
                        return True
            elif isinstance(v, list):
                for vv in v:
                    if rec(vv):
                        return True
            return False
        if rec(p):
            return True

    simple_props = e.get("Properties")
    if isinstance(simple_props, dict) and isinstance(simple_props.get(name), dict) and "A" in simple_props[name]:
        old = simple_props[name].get("A")
        simple_props[name]["A"] = float(alpha)
        changes.append(f"{label}: Properties.{name}.A {old} -> {alpha}")
        return True
    return False

try:
    data = json.loads(src.read_text(encoding="utf-8-sig"))
    exports = data.get("Exports", []) if isinstance(data, dict) else data

    if isinstance(exports, list):
        for i, e in enumerate(exports):
            if isinstance(e, dict) and is_target(e):
                label = f"export[{i}] {export_name(e)}"
                targets.append(label)
                set_enum_prop(e, "Visibility", "ESlateVisibility::HitTestInvisible", label)
                set_float_prop(e, "RenderOpacity", 1.0, label)
                set_linear_alpha(e, "ColorAndOpacity", 1.0, label)
                set_linear_alpha(e, "BrushColor", 1.0, label)

    dst.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    report = []
    report.append("UMG_OverlayPlayerMapPin local directional marker visibility probe")
    report.append(f"Targets: {len(targets)}")
    report.extend(targets)
    report.append("")
    report.append(f"Changes: {len(changes)}")
    report.extend(changes)
    log.write_text("\n".join(report) + "\n", encoding="utf-8")

    print(f"Overlay player pin targets: {len(targets)}")
    print(f"Patch changes: {len(changes)}")
    for c in changes:
        print(" - " + c)

except Exception:
    log.write_text("PATCH FAILED\n\n" + traceback.format_exc(), encoding="utf-8")
    print("PATCH FAILED")
    traceback.print_exc()
    sys.exit(1)

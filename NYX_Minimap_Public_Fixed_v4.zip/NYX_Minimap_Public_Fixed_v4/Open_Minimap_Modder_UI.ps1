$Dir=Split-Path -Parent $MyInvocation.MyCommand.Path
PowerShell -ExecutionPolicy Bypass -File "$Dir\Minimap_Modder_UI.ps1"

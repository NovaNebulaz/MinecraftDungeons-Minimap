import json
import sys
import pathlib
import traceback

src = pathlib.Path(sys.argv[1])
dst = pathlib.Path(sys.argv[2])
log = dst.with_suffix(".patch_report.txt")

# Smaller border preset.
# Keeps explored fill visible while reducing border thickness.
TARGETS = {
    "GroundOpacity": 0.90,
    "OutlineOpacity": 1.05,
    "Width": 2.10,
    "RefractionDepthBias": 0.00,
}

changes = []
param_reports = []

def find_param_name(param_struct):
    if isinstance(param_struct, dict):
        pi = param_struct.get("ParameterInfo")
        if isinstance(pi, dict) and "Name" in pi:
            return str(pi.get("Name"))

    found = []

    def rec(x):
        if isinstance(x, dict):
            if x.get("Name") == "Name" and "Value" in x:
                found.append(str(x.get("Value")))
            if isinstance(x.get("ParameterInfo"), dict) and "Name" in x["ParameterInfo"]:
                found.append(str(x["ParameterInfo"].get("Name")))
            for v in x.values():
                rec(v)
        elif isinstance(x, list):
            for v in x:
                rec(v)

    rec(param_struct)

    for v in found:
        if v in TARGETS:
            return v
    return found[0] if found else ""

def patch_parameter_value(param_struct, param_name, new_value, path):
    patched = 0

    if isinstance(param_struct, dict):
        if "ParameterValue" in param_struct and isinstance(param_struct.get("ParameterValue"), (int, float, str)):
            old = param_struct.get("ParameterValue")
            param_struct["ParameterValue"] = float(new_value)
            changes.append(f"{path}: {param_name} simple ParameterValue {old} -> {new_value}")
            patched += 1

        def rec(x, pth):
            nonlocal patched
            if patched:
                return
            if isinstance(x, dict):
                if x.get("Name") == "ParameterValue" and "FloatPropertyData" in str(x.get("$type")):
                    old = x.get("Value")
                    x["Value"] = float(new_value)
                    changes.append(f"{pth}: {param_name} Float ParameterValue {old} -> {new_value}")
                    patched += 1
                    return
                for k, v in x.items():
                    rec(v, f"{pth}.{k}")
            elif isinstance(x, list):
                for i, v in enumerate(x):
                    rec(v, f"{pth}[{i}]")

        rec(param_struct, path)

    return patched

def iter_scalar_parameter_entries(data):
    if isinstance(data, list):
        for i, obj in enumerate(data):
            props = obj.get("Properties") if isinstance(obj, dict) else None
            if isinstance(props, dict) and isinstance(props.get("ScalarParameterValues"), list):
                for j, entry in enumerate(props["ScalarParameterValues"]):
                    yield entry, f"root[{i}].Properties.ScalarParameterValues[{j}]"

    def rec(x, path):
        if isinstance(x, dict):
            if x.get("Name") == "ScalarParameterValues" and isinstance(x.get("Value"), list):
                for i, entry in enumerate(x["Value"]):
                    yield entry, f"{path}.Value[{i}]"
                return
            for k, v in x.items():
                yield from rec(v, f"{path}.{k}")
        elif isinstance(x, list):
            for i, v in enumerate(x):
                yield from rec(v, f"{path}[{i}]")

    yield from rec(data, "root")

try:
    data = json.loads(src.read_text(encoding="utf-8-sig"))

    for entry, path in iter_scalar_parameter_entries(data):
        pname = find_param_name(entry)
        if pname:
            param_reports.append(f"{path}: {pname}")
        if pname in TARGETS:
            count = patch_parameter_value(entry, pname, TARGETS[pname], path)
            if count == 0:
                changes.append(f"{path}: FOUND {pname} but no ParameterValue float was patched")

    dst.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    report = []
    report.append("M_MapOverlay_Inst smaller-border patch")
    report.append("Target values:")
    for k, v in TARGETS.items():
        report.append(f"{k}={v}")
    report.append("")
    report.append("Detected scalar parameters:")
    report.extend(param_reports)
    report.append("")
    report.append(f"Changes: {len(changes)}")
    report.extend(changes)
    log.write_text("\n".join(report) + "\n", encoding="utf-8")

    print(f"Detected scalar params: {len(param_reports)}")
    print(f"Patched material changes: {len(changes)}")
    for c in changes:
        print(" - " + c)

    if not changes:
        print("WARNING: no material changes were made. Upload this patch report.")

except Exception:
    log.write_text("PATCH FAILED\n\n" + traceback.format_exc(), encoding="utf-8")
    print("PATCH FAILED")
    traceback.print_exc()
    sys.exit(1)

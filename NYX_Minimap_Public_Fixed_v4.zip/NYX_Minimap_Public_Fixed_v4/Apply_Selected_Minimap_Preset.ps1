param([string]$GameExe="",[string]$UAssetGUI="",[string]$Settings="")
$ErrorActionPreference="Stop"
$Root=$PSScriptRoot
$ConfigPath=Join-Path $Root "nyx_launcher_config.json"
if(Test-Path $ConfigPath){
    $Cfg=Get-Content $ConfigPath -Raw|ConvertFrom-Json
    if([string]::IsNullOrWhiteSpace($GameExe)){$GameExe=[string]$Cfg.GameExe}
    if([string]::IsNullOrWhiteSpace($UAssetGUI)){$UAssetGUI=[string]$Cfg.UAssetGUI}
}
if([string]::IsNullOrWhiteSpace($Settings)){$Settings=Join-Path $Root "nyx_minimap_settings.json"}
if(!(Test-Path $GameExe)){throw "Game exe not found: $GameExe"}
if(!(Test-Path $UAssetGUI)){throw "UAssetGUI not found: $UAssetGUI"}
if(!(Test-Path $Settings)){throw "Settings not found: $Settings"}

$Common=Join-Path $Root "NYX_Minimap_Common.ps1"
if(!(Test-Path "$Common.NYX_ORIGINAL")){Copy-Item $Common "$Common.NYX_ORIGINAL" -Force}
$Text=Get-Content "$Common.NYX_ORIGINAL" -Raw
$Escaped=$GameExe.Replace('\','\\')
$Text=$Text -replace '\$PreferredGameExe\s*=\s*".*?"',('$PreferredGameExe = "'+$Escaped+'"')
$Text=$Text -replace 'NYX_Minimap_Build_Work','NYX_Minimap_Build_Work'
Set-Content -LiteralPath $Common -Value $Text -Encoding UTF8

Write-Host "NYX Minimap applying preset" -ForegroundColor Cyan
Write-Host "GameExe: $GameExe"
Write-Host "UAssetGUI: $UAssetGUI"
Write-Host "Settings: $Settings"
Write-Host ""
PowerShell -ExecutionPolicy Bypass -File (Join-Path $Root "Build_And_Install_Minimap.ps1") -UAssetGUI $UAssetGUI -Settings $Settings

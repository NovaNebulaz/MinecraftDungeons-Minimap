import json
import sys
import pathlib
import traceback

src = pathlib.Path(sys.argv[1])
dst = pathlib.Path(sys.argv[2])
log = dst.with_suffix(".patch_report.txt")

LEFT = 56.0
TOP = 76.0
WIDTH = 420.0
HEIGHT = 420.0

changes = []
slot_reports = []

def obj_name(data, ref):
    if not isinstance(ref, int):
        return ""
    if ref > 0:
        i = ref - 1
        if 0 <= i < len(data.get("Exports", [])):
            return str(data["Exports"][i].get("ObjectName") or "")
    if ref < 0:
        i = -ref - 1
        if 0 <= i < len(data.get("Imports", [])):
            return str(data["Imports"][i].get("ObjectName") or "")
    return ""

def props(e):
    return [p for p in e.get("Data", []) if isinstance(p, dict) and "Name" in p]

def prop(e, name):
    for p in props(e):
        if p.get("Name") == name:
            return p
    return None

def prop_value(e, name):
    p = prop(e, name)
    return p.get("Value") if p else None

def find_struct(layout_value, struct_name):
    if not isinstance(layout_value, list):
        return None
    for s in layout_value:
        if isinstance(s, dict) and s.get("Name") == struct_name:
            return s
    return None

def find_float(struct, float_name):
    if not isinstance(struct, dict):
        return None
    value = struct.get("Value")
    if not isinstance(value, list):
        return None
    for p in value:
        if isinstance(p, dict) and p.get("Name") == float_name:
            return p
    return None

def set_margin(layout_value, left, top, right, bottom, where):
    offsets = find_struct(layout_value, "Offsets")
    if offsets is None:
        changes.append(f"{where}: ERROR no Offsets struct")
        return

    wanted = {"Left": left, "Top": top, "Right": right, "Bottom": bottom}
    for k, v in wanted.items():
        p = find_float(offsets, k)
        if p is None:
            existing = None
            for x in offsets.get("Value", []):
                if isinstance(x, dict) and "FloatPropertyData" in str(x.get("$type")):
                    existing = json.loads(json.dumps(x))
                    break
            if existing is None:
                changes.append(f"{where}: ERROR no float template for {k}")
                continue
            existing["Name"] = k
            existing["Value"] = float(v)
            offsets.setdefault("Value", []).append(existing)
            changes.append(f"{where}: added Offset.{k}={v}")
        else:
            old = p.get("Value")
            p["Value"] = float(v)
            changes.append(f"{where}: Offset.{k} {old} -> {v}")

def set_vec2d_prop(struct_prop, vec_name, x, y, where):
    if not isinstance(struct_prop, dict):
        changes.append(f"{where}: ERROR no {vec_name} struct")
        return

    vals = struct_prop.get("Value")
    if not isinstance(vals, list):
        changes.append(f"{where}: ERROR bad {vec_name} value")
        return

    for sub in vals:
        if isinstance(sub, dict) and sub.get("Name") == vec_name:
            inner_vals = sub.get("Value")
            if isinstance(inner_vals, list):
                for vprop in inner_vals:
                    if isinstance(vprop, dict) and "Vector2DPropertyData" in str(vprop.get("$type")):
                        val = vprop.get("Value")
                        if isinstance(val, dict):
                            old = (val.get("X"), val.get("Y"))
                            val["X"] = float(x)
                            val["Y"] = float(y)
                            changes.append(f"{where}: {vec_name} {old} -> ({x},{y})")
                            return
            if "Vector2DPropertyData" in str(sub.get("$type")):
                val = sub.get("Value")
                if isinstance(val, dict):
                    old = (val.get("X"), val.get("Y"))
                    val["X"] = float(x)
                    val["Y"] = float(y)
                    changes.append(f"{where}: {vec_name} {old} -> ({x},{y})")
                    return

    # Clone an existing vector if missing.
    template = None
    for sub in vals:
        if isinstance(sub, dict):
            template = json.loads(json.dumps(sub))
            break
    if template is None:
        changes.append(f"{where}: ERROR no vector template for {vec_name}")
        return
    template["Name"] = vec_name
    for sub in template.get("Value", []):
        if isinstance(sub, dict):
            sub["Name"] = vec_name
            if isinstance(sub.get("Value"), dict):
                sub["Value"]["X"] = float(x)
                sub["Value"]["Y"] = float(y)
    vals.append(template)
    changes.append(f"{where}: added {vec_name}=({x},{y})")

def set_anchors(layout_value, minx, miny, maxx, maxy, where):
    anchors = find_struct(layout_value, "Anchors")
    if anchors is None:
        changes.append(f"{where}: ERROR no Anchors struct")
        return
    set_vec2d_prop(anchors, "Minimum", minx, miny, where)
    set_vec2d_prop(anchors, "Maximum", maxx, maxy, where)

def patch_canvas_slot(data, export_index, label):
    e = data["Exports"][export_index]
    layout = prop(e, "LayoutData")
    if layout is None:
        changes.append(f"{label}: ERROR no LayoutData property")
        return

    layout_value = layout.get("Value")
    set_margin(layout_value, LEFT, TOP, WIDTH, HEIGHT, label)
    set_anchors(layout_value, 0.0, 0.0, 0.0, 0.0, label)

def main():
    data = json.loads(src.read_text(encoding="utf-8-sig"))

    targets = []
    for i, e in enumerate(data.get("Exports", [])):
        parent = obj_name(data, prop_value(e, "Parent"))
        content = obj_name(data, prop_value(e, "Content"))
        name = str(e.get("ObjectName") or "")

        if parent or content:
            if "MapOverlay" in parent or "MapOverlay" in content or content == "MapOverlay_Panel":
                slot_reports.append(f"export[{i}] ref={i+1} name={name} parent={parent} content={content}")

        # Only move the parent panel. Do not edit the child UMG_MapOverlay slot, because older build may have hidden the directional marker.
        if parent == "CanvasPanel_0" and content == "MapOverlay_Panel":
            targets.append((i, f"export[{i}] {name} CanvasPanel_0 -> MapOverlay_Panel"))

    for i, label in targets:
        patch_canvas_slot(data, i, label)

    dst.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    report = []
    report.append(f"JSON root type: {type(data).__name__}")
    report.append(f"Parent map panel target slots found: {len(targets)}")
    report.append("")
    report.append("Slot reports:")
    report.extend(slot_reports)
    report.append("")
    report.append(f"Changes: {len(changes)}")
    report.extend(changes)
    log.write_text("\n".join(report) + "\n", encoding="utf-8")

    print(f"Parent map panel target slots found: {len(targets)}")
    print(f"Patched changes: {len(changes)}")
    for t in targets:
        print("TARGET", t)
    for c in changes:
        print(" - " + c)

try:
    main()
except Exception:
    log.write_text("PATCH FAILED\n\n" + traceback.format_exc(), encoding="utf-8")
    print("PATCH FAILED")
    traceback.print_exc()
    sys.exit(1)

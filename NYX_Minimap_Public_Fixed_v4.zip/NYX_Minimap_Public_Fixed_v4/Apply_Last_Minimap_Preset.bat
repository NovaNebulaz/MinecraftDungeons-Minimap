@echo off
cd /d "%~dp0"
start "" powershell.exe -NoProfile -NoExit -ExecutionPolicy Bypass -File "%~dp0Apply_Selected_Minimap_Preset.ps1"

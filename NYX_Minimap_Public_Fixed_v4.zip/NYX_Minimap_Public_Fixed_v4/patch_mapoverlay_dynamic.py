import json
import sys
import pathlib
import traceback

src = pathlib.Path(sys.argv[1])
dst = pathlib.Path(sys.argv[2])
settings_path = pathlib.Path(sys.argv[3]) if len(sys.argv) >= 4 else pathlib.Path("nyx_minimap_settings.json")
log = dst.with_suffix(".patch_report.txt")

try:
    if settings_path.exists():
        user_settings = json.loads(settings_path.read_text(encoding="utf-8-sig"))
    else:
        user_settings = {}
except Exception:
    user_settings = {}

def get_float(name, default):
    try:
        return float(user_settings.get(name, default))
    except Exception:
        return float(default)

TARGET_SCALE = get_float("MapScale", 3.50)
ASPECT_X = get_float("MapAspectScaleX", 1.0)
ASPECT_Y = get_float("MapAspectScaleY", 1.0)

changes = []
target_reports = []

def props(e):
    return [p for p in e.get("Data", []) if isinstance(p, dict) and "Name" in p]

def prop(e, name):
    for p in props(e):
        if p.get("Name") == name:
            return p
    return None

def set_float_prop(e, name, value, label):
    p = prop(e, name)
    if p and "FloatPropertyData" in str(p.get("$type")):
        old = p.get("Value")
        p["Value"] = float(value)
        changes.append(f"{label}: {name} {old} -> {value}")
        return True
    simple_props = e.get("Properties")
    if isinstance(simple_props, dict) and isinstance(simple_props.get(name), (int, float)):
        old = simple_props.get(name)
        simple_props[name] = float(value)
        changes.append(f"{label}: Properties.{name} {old} -> {value}")
        return True
    return False

def set_bool_prop(e, name, value, label):
    p = prop(e, name)
    if p and "BoolPropertyData" in str(p.get("$type")):
        old = p.get("Value")
        p["Value"] = bool(value)
        changes.append(f"{label}: {name} {old} -> {value}")
        return True
    simple_props = e.get("Properties")
    if isinstance(simple_props, dict) and isinstance(simple_props.get(name), bool):
        old = simple_props.get(name)
        simple_props[name] = bool(value)
        changes.append(f"{label}: Properties.{name} {old} -> {value}")
        return True
    return False

def set_vec2d_prop(e, name, x, y, label):
    p = prop(e, name)
    if p:
        def rec(v):
            if isinstance(v, dict):
                if "Vector2DPropertyData" in str(v.get("$type")) and isinstance(v.get("Value"), dict):
                    old = (v["Value"].get("X"), v["Value"].get("Y"))
                    v["Value"]["X"] = float(x)
                    v["Value"]["Y"] = float(y)
                    changes.append(f"{label}: {name} {old} -> ({x},{y})")
                    return True
                for vv in v.values():
                    if rec(vv):
                        return True
            elif isinstance(v, list):
                for vv in v:
                    if rec(vv):
                        return True
            return False
        if rec(p):
            return True
    simple_props = e.get("Properties")
    if isinstance(simple_props, dict) and isinstance(simple_props.get(name), dict):
        old = (simple_props[name].get("X"), simple_props[name].get("Y"))
        simple_props[name]["X"] = float(x)
        simple_props[name]["Y"] = float(y)
        changes.append(f"{label}: Properties.{name} {old} -> ({x},{y})")
        return True
    return False

def is_map_canvas_export(e):
    name = str(e.get("ObjectName") or e.get("Name") or "")
    typ = str(e.get("$type") or e.get("Type") or e.get("Class") or "")
    has_maptype = prop(e, "MapType") is not None or (isinstance(e.get("Properties"), dict) and "MapType" in e.get("Properties"))
    has_scale = prop(e, "Scale") is not None or (isinstance(e.get("Properties"), dict) and "Scale" in e.get("Properties"))
    return "UMG_MapCanvas" in name or ("UMG_MapCanvas" in typ and has_maptype) or (has_maptype and has_scale)

try:
    data = json.loads(src.read_text(encoding="utf-8-sig"))
    exports = data.get("Exports", []) if isinstance(data, dict) else data

    targets = []
    if isinstance(exports, list):
        for i, e in enumerate(exports):
            if isinstance(e, dict) and is_map_canvas_export(e):
                targets.append((i, e))

    for i, e in targets:
        label = f"export[{i}] {e.get('ObjectName') or e.get('Name')}"
        target_reports.append(label)
        set_vec2d_prop(e, "MapAspectScale", ASPECT_X, ASPECT_Y, label)
        set_float_prop(e, "Scale", TARGET_SCALE, label)
        set_bool_prop(e, "ShowLocalPlayer", True, label)
        set_float_prop(e, "PlayerOpacity", 1.0, label)
        set_float_prop(e, "Opacity", 1.0, label)

    dst.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    report = []
    report.append("UMG_MapOverlay Minimap UI-driven expanded-range patch")
    report.append(f"Settings file: {settings_path}")
    report.append("Targets:")
    report.extend(target_reports)
    report.append("")
    report.append("Patch values:")
    report.append("HUD corner panel remains 420x420 from PlayerHUD patch")
    report.append(f"MapAspectScale=({ASPECT_X},{ASPECT_Y})")
    report.append(f"Scale={TARGET_SCALE}")
    report.append("MapType is NOT changed")
    report.append("ShowLocalPlayer=True")
    report.append("PlayerOpacity=1.0")
    report.append("Opacity=1.0")
    report.append("")
    report.append(f"Changes: {len(changes)}")
    report.extend(changes)
    log.write_text("\n".join(report) + "\n", encoding="utf-8")

    print(f"MapOverlay MapCanvas targets: {len(targets)}")
    print(f"Patch changes: {len(changes)}")
    for c in changes:
        print(" - " + c)

except Exception:
    log.write_text("PATCH FAILED\n\n" + traceback.format_exc(), encoding="utf-8")
    print("PATCH FAILED")
    traceback.print_exc()
    sys.exit(1)

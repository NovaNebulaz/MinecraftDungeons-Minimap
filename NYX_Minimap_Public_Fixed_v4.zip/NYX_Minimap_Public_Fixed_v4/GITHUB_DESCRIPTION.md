# NYX Minimap Modder for Minecraft Dungeons

NYX Minimap Modder adds a configurable corner minimap setup for Minecraft Dungeons using a simple Windows launcher UI.

## Features

- Launcher-style minimap UI
- Preset selector
- Custom minimap range values
- Supports any positive `MapScale` value
- Minimap opacity controls
- Border opacity and width controls
- Built-in preview panel
- Auto-detects common Minecraft Dungeons install paths
- Manual browse option for `Dungeons-Win64-Shipping.exe` or `Dungeons.exe`
- UAssetGUI path selector
- One-click apply / rebuild
- Remove Mod button
- Launch Game button
- Open Paks Folder button

## Requirements

- `UAssetGUI.exe` is required for Apply / Rebuild.
- `UnrealPak.exe` is required to build the final pak.
- Extract the full release zip before running the tool.
- Keep the included `BaseAssets` folder next to the launcher files.

## How to install

1. Download and extract the release zip.
2. Run `Open_Minimap_Modder.bat`.
3. Select your Minecraft Dungeons executable.
4. Select `UAssetGUI.exe`.
5. Choose a preset or enter custom values.
6. Click `Apply / Rebuild`.
7. Start Minecraft Dungeons.

## Range guide

`MapScale` controls how far the minimap sees.

- Lower value = farther range
- Higher value = closer range

Examples:

- `0.15` = very far
- `0.35` = max range preset
- `1.60` = balanced
- `3.50` = close detail

## Removing the mod

Use the `Remove Mod` button in the launcher, or run `Remove_NYX_Minimap.ps1`.

## Included files

- `Open_Minimap_Modder.bat` opens the launcher UI.
- `Minimap_Modder_UI.ps1` is the main UI.
- `Apply_Selected_Minimap_Preset.ps1` applies selected settings.
- `Build_And_Install_Minimap.ps1` rebuilds and installs the pak.
- `Remove_NYX_Minimap.ps1` removes installed NYX minimap paks.
- `BaseAssets` contains the required source assets for rebuilding.


## Requirements

Apply / Rebuild requires:

- `UAssetGUI.exe`
- `UnrealPak.exe`
- Python 3.10+

When installing Python on Windows, enable **Add python.exe to PATH**. After installing Python, close and reopen the minimap launcher.

## Steam users

Steam installs are supported. If the tool says `python.exe : python not found`, the Steam path is not the problem. Python is missing or Windows is pointing to the Microsoft Store Python alias instead of a real Python install.

Fix:

1. Install Python 3.10 or newer.
2. Enable **Add python.exe to PATH** during install.
3. Close and reopen `Open_Minimap_Modder.bat`.
4. Apply / Rebuild again.

@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$c=Get-Content '%~dp0nyx_launcher_config.json' -Raw|ConvertFrom-Json; if(Test-Path $c.GameExe){Start-Process $c.GameExe}else{Write-Host 'Game exe missing. Open the modder and browse to the exe.'; pause}"

param(
    [string]$UAssetGUI = "",
    [string]$Settings = ""
)

. "$PSScriptRoot\NYX_Minimap_Common.ps1"

Write-Host "NYX Minimap: build and install" -ForegroundColor Cyan
Write-Host "Applies the selected minimap opacity, border, and range settings." -ForegroundColor Yellow

$paths = Get-GamePaths
$UAssetGUI = Find-UAssetGUI $UAssetGUI

if ([string]::IsNullOrWhiteSpace($Settings)) {
    $Settings = Join-Path $PSScriptRoot "nyx_minimap_settings.json"
}

if (!(Test-Path $Settings)) {
@"
{
  "GroundOpacity": 0.92,
  "OutlineOpacity": 1.40,
  "Width": 2.10,
  "RefractionDepthBias": 0.0,
  "MapScale": 3.50,
  "MapAspectScaleX": 1.0,
  "MapAspectScaleY": 1.0
}
"@ | Set-Content -LiteralPath $Settings -Encoding UTF8
}

Write-Host "Using settings: $Settings" -ForegroundColor Gray
Get-Content $Settings | Write-Host

Stop-Dungeons
Disable-NYXRuntime $paths.ModsTxt
Remove-OldNYXPaks $paths.PakDir

$Stage = Join-Path $WorkRoot "Stage_Minimap"
$Temp = Join-Path $WorkRoot "Temp"
$Logs = Join-Path $WorkRoot "Logs"
$PakOut = Join-Path $WorkRoot "zzz_NYX_Minimap_P.pak"
Remove-Item $Stage,$Temp,$Logs -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force $Stage,$Temp,$Logs | Out-Null

$Python = Find-Python
$PythonExe = $Python.Exe
$PythonArgs = @($Python.Args)
Write-Host "Using Python: $($Python.Version)" -ForegroundColor Gray

function Patch-UAssetJson {
    param(
        [string]$RelativeUAsset,
        [string]$FileName,
        [string]$Patcher,
        [string]$BaseName,
        [string]$LogPrefix,
        [switch]$PassSettings
    )

    $relUExp = $RelativeUAsset.Substring(0, $RelativeUAsset.Length - 7) + ".uexp"
    $srcUAsset = Find-ExtractedAsset -RelativePath $RelativeUAsset -FileNameFallback $FileName
    $srcUExp = Find-ExtractedAsset -RelativePath $relUExp -FileNameFallback ($FileName.Substring(0, $FileName.Length - 7) + ".uexp")

    $workUAsset = Join-Path $Temp $FileName
    $workUExp = Join-Path $Temp ($FileName.Substring(0, $FileName.Length - 7) + ".uexp")
    $jsonRaw = Join-Path $Temp ($BaseName + ".raw.json")
    $jsonPatched = Join-Path $Temp ($BaseName + ".patched.json")
    $outUAsset = Join-Path $Stage $RelativeUAsset
    $outUExp = Join-Path $Stage $relUExp

    New-Item -ItemType Directory -Force (Split-Path $outUAsset -Parent) | Out-Null
    Copy-Item $srcUAsset $workUAsset -Force
    Copy-Item $srcUExp $workUExp -Force

    Write-Host "Exporting $BaseName to JSON..."
    & $UAssetGUI tojson $workUAsset $jsonRaw VER_UE4_22 2>&1 | Tee-Object -FilePath (Join-Path $Logs "$LogPrefix`_tojson.log")
    if (!(Test-Path $jsonRaw)) { throw "$BaseName tojson failed." }

    Write-Host "Patching $BaseName..."
    if ($PassSettings) {
        & $PythonExe @PythonArgs "$PSScriptRoot\$Patcher" $jsonRaw $jsonPatched $Settings 2>&1 | Tee-Object -FilePath (Join-Path $Logs "$LogPrefix`_patch.log")
    } else {
        & $PythonExe @PythonArgs "$PSScriptRoot\$Patcher" $jsonRaw $jsonPatched 2>&1 | Tee-Object -FilePath (Join-Path $Logs "$LogPrefix`_patch.log")
    }
    if (!(Test-Path $jsonPatched)) { throw "$BaseName patch failed." }

    Write-Host "Importing patched $BaseName..."
    & $UAssetGUI fromjson $jsonPatched $outUAsset 2>&1 | Tee-Object -FilePath (Join-Path $Logs "$LogPrefix`_fromjson.log")
    if (!(Test-Path $outUAsset)) { throw "$BaseName fromjson failed." }
    if (!(Test-Path $outUExp)) {
        Copy-Item $workUExp $outUExp -Force
    }
}

Patch-UAssetJson `
    -RelativeUAsset "Dungeons\Content\UI\PlayerHUD\UMG_PlayerHUD.uasset" `
    -FileName "UMG_PlayerHUD.uasset" `
    -Patcher "patch_playerhud_parent_slot_only.py" `
    -BaseName "UMG_PlayerHUD" `
    -LogPrefix "01_hud"

Patch-UAssetJson `
    -RelativeUAsset "Dungeons\Content\Materials\M_MapOverlay_Inst.uasset" `
    -FileName "M_MapOverlay_Inst.uasset" `
    -Patcher "patch_explore_fill_dynamic.py" `
    -BaseName "M_MapOverlay_Inst" `
    -LogPrefix "02_material" `
    -PassSettings

Patch-UAssetJson `
    -RelativeUAsset "Dungeons\Content\UI\Map\UMG_MapOverlay.uasset" `
    -FileName "UMG_MapOverlay.uasset" `
    -Patcher "patch_mapoverlay_dynamic.py" `
    -BaseName "UMG_MapOverlay" `
    -LogPrefix "03_mapoverlay" `
    -PassSettings

Build-PakFromStage -StageRoot $Stage -PakOut $PakOut
Copy-Item $PakOut (Join-Path $paths.PakDir "zzz_NYX_Minimap_P.pak") -Force

Write-Host ""
Write-Host "DONE. Installed:" -ForegroundColor Green
Write-Host (Join-Path $paths.PakDir "zzz_NYX_Minimap_P.pak")
Write-Host ""
Write-Host ""
pause

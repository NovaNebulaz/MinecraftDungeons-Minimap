import json
import sys
import pathlib
import traceback

src = pathlib.Path(sys.argv[1])
dst = pathlib.Path(sys.argv[2])
settings_path = pathlib.Path(sys.argv[3]) if len(sys.argv) >= 4 else pathlib.Path("nyx_minimap_settings.json")
log = dst.with_suffix(".patch_report.txt")

DEFAULTS = {
    "GroundOpacity": 0.92,
    "OutlineOpacity": 1.40,
    "Width": 2.10,
    "RefractionDepthBias": 0.00,
}

try:
    if settings_path.exists():
        user_settings = json.loads(settings_path.read_text(encoding="utf-8-sig"))
    else:
        user_settings = {}
except Exception:
    user_settings = {}

TARGETS = {}
for k, v in DEFAULTS.items():
    try:
        TARGETS[k] = float(user_settings.get(k, v))
    except Exception:
        TARGETS[k] = float(v)

changes = []
param_reports = []

def find_param_name(param_struct):
    if isinstance(param_struct, dict):
        pi = param_struct.get("ParameterInfo")
        if isinstance(pi, dict) and "Name" in pi:
            return str(pi.get("Name"))

    found = []

    def rec(x):
        if isinstance(x, dict):
            if x.get("Name") == "Name" and "Value" in x:
                found.append(str(x.get("Value")))
            if isinstance(x.get("ParameterInfo"), dict) and "Name" in x["ParameterInfo"]:
                found.append(str(x["ParameterInfo"].get("Name")))
            for v in x.values():
                rec(v)
        elif isinstance(x, list):
            for v in x:
                rec(v)

    rec(param_struct)

    for v in found:
        if v in TARGETS:
            return v
    return found[0] if found else ""

def patch_parameter_value(param_struct, param_name, new_value, path):
    patched = 0

    if isinstance(param_struct, dict):
        if "ParameterValue" in param_struct and isinstance(param_struct.get("ParameterValue"), (int, float, str)):
            old = param_struct.get("ParameterValue")
            param_struct["ParameterValue"] = float(new_value)
            changes.append(f"{path}: {param_name} simple ParameterValue {old} -> {new_value}")
            patched += 1

        def rec(x, pth):
            nonlocal patched
            if patched:
                return
            if isinstance(x, dict):
                if x.get("Name") == "ParameterValue" and "FloatPropertyData" in str(x.get("$type")):
                    old = x.get("Value")
                    x["Value"] = float(new_value)
                    changes.append(f"{pth}: {param_name} Float ParameterValue {old} -> {new_value}")
                    patched += 1
                    return
                for k, v in x.items():
                    rec(v, f"{pth}.{k}")
            elif isinstance(x, list):
                for i, v in enumerate(x):
                    rec(v, f"{pth}[{i}]")

        rec(param_struct, path)

    return patched

def iter_scalar_parameter_entries(data):
    def rec(x, path):
        if isinstance(x, dict):
            if x.get("Name") == "ScalarParameterValues" and isinstance(x.get("Value"), list):
                for i, entry in enumerate(x["Value"]):
                    yield entry, f"{path}.Value[{i}]"
                return
            for k, v in x.items():
                yield from rec(v, f"{path}.{k}")
        elif isinstance(x, list):
            for i, v in enumerate(x):
                yield from rec(v, f"{path}[{i}]")
    yield from rec(data, "root")

try:
    data = json.loads(src.read_text(encoding="utf-8-sig"))

    for entry, path in iter_scalar_parameter_entries(data):
        pname = find_param_name(entry)
        if pname:
            param_reports.append(f"{path}: {pname}")
        if pname in TARGETS:
            count = patch_parameter_value(entry, pname, TARGETS[pname], path)
            if count == 0:
                changes.append(f"{path}: FOUND {pname} but no ParameterValue float was patched")

    dst.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    report = []
    report.append("M_MapOverlay_Inst Minimap untraveled-border/UI material patch")
    report.append(f"Settings file: {settings_path}")
    report.append("")
    report.append("Target values:")
    for k, v in TARGETS.items():
        report.append(f"{k}={v}")
    report.append("")
    report.append("Detected scalar parameters:")
    report.extend(param_reports)
    report.append("")
    report.append(f"Changes: {len(changes)}")
    report.extend(changes)
    log.write_text("\n".join(report) + "\n", encoding="utf-8")

    print(f"Detected scalar params: {len(param_reports)}")
    print(f"Patched material changes: {len(changes)}")
    for c in changes:
        print(" - " + c)

except Exception:
    log.write_text("PATCH FAILED\n\n" + traceback.format_exc(), encoding="utf-8")
    print("PATCH FAILED")
    traceback.print_exc()
    sys.exit(1)

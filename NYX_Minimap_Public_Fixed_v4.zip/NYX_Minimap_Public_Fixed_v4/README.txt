NYX Minimap Modder for Minecraft Dungeons

Open the launcher with:

  Open_Minimap_Modder.bat

What this does
- Rebuilds and installs the NYX corner minimap pak.
- Lets you choose a preset or enter your own MapScale value.
- Lets you adjust minimap opacity and border width.
- Includes a Remove Mod button in the UI.

Required tools
- UAssetGUI.exe is required for Apply / Rebuild.
Python 3.10 or newer is required for Apply / Rebuild. During install, enable Add python.exe to PATH.
UnrealPak.exe is required to build the final pak.
- UnrealPak.exe is required to build the final pak.

Where to get ready
1. Extract the full zip before running anything. Do not run it from inside the zip viewer.
2. Put UAssetGUI.exe somewhere easy, or use the Browse button in the UI.
3. Install Unreal Engine 4.22 or place UnrealPak.exe in Downloads/UGUI or Downloads.
4. Run Open_Minimap_Modder.bat.
5. Select your Minecraft Dungeons exe.
6. Select UAssetGUI.exe.
7. Pick a preset or enter custom values.
8. Click Apply / Rebuild.

Important folder
The release includes a BaseAssets folder. Do not delete it. The rebuild tool uses it as the source asset folder so you do not need to manually extract game assets first.

Range guide
- Lower MapScale = farther minimap range.
- Higher MapScale = closer minimap range.
- Any positive MapScale value is supported.

Default game path used by the launcher
C:\Games\Minecraft Dungeons\Dungeons\Binaries\Win64\Dungeons-Win64-Shipping.exe

Remove the mod
Use the Remove Mod button in the launcher, or run:

  Remove_NYX_Minimap.ps1

Included files
- Open_Minimap_Modder.bat: opens the launcher UI
- Minimap_Modder_UI.ps1: main launcher UI
- Apply_Selected_Minimap_Preset.ps1: saves and applies selected settings
- Build_And_Install_Minimap.ps1: rebuilds and installs the pak
- Remove_NYX_Minimap.ps1: removes installed NYX minimap paks
- BaseAssets: required source assets for rebuilding

Steam note:
Steam installs are supported. If a Steam user gets python.exe : python not found, the game path is not the issue. Install Python 3 and reopen the launcher.

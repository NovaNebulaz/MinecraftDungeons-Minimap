# NYX Minimap shared build functions
$ErrorActionPreference = "Stop"

$PreferredGameExe = "C:\Games\Minecraft Dungeons\Dungeons\Binaries\Win64\Dungeons-Win64-Shipping.exe"
$WorkRoot = Join-Path $env:USERPROFILE "Downloads\NYX_Minimap_Build_Work"

function Find-DungeonsExe {
    param([string]$Preferred)
    if (Test-Path $Preferred) { return $Preferred }

    $roots = @("C:\Games","C:\XboxGames","C:\Program Files (x86)\Steam\steamapps\common","$env:USERPROFILE\Downloads")
    foreach ($r in $roots) {
        if (Test-Path $r) {
            $hit = Get-ChildItem $r -Filter "Dungeons-Win64-Shipping.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($hit) { return $hit.FullName }
        }
    }
    throw "Could not find Dungeons-Win64-Shipping.exe"
}

function Find-UnrealPak {
    $candidates = @(
        "C:\Program Files\Epic Games\UE_4.22\Engine\Binaries\Win64\UnrealPak.exe",
        "C:\Program Files\Epic Games\UE_4.23\Engine\Binaries\Win64\UnrealPak.exe",
        "C:\Program Files\Epic Games\UE_4.24\Engine\Binaries\Win64\UnrealPak.exe",
        "C:\Program Files\Epic Games\UE_4.25\Engine\Binaries\Win64\UnrealPak.exe",
        "C:\Program Files\Epic Games\UE_4.26\Engine\Binaries\Win64\UnrealPak.exe",
        "C:\Program Files\Epic Games\UE_4.27\Engine\Binaries\Win64\UnrealPak.exe",
        "$env:USERPROFILE\Downloads\UGUI\UnrealPak.exe",
        "$env:USERPROFILE\Downloads\UnrealPak.exe"
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) { return $c }
    }
    foreach ($r in @("$env:USERPROFILE\Downloads", "$env:USERPROFILE\Desktop", "C:\Program Files\Epic Games")) {
        if (Test-Path $r) {
            $hit = Get-ChildItem $r -Filter "UnrealPak.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($hit) { return $hit.FullName }
        }
    }
    throw "Could not find UnrealPak.exe"
}

function Find-UAssetGUI {
    param([string]$Preferred)
    $candidates = @()
    if ($Preferred -and (Test-Path $Preferred)) { $candidates += $Preferred }
    $candidates += "$PWD\UAssetGUI.exe"
    $candidates += "$PSScriptRoot\UAssetGUI.exe"
    $candidates += "$env:USERPROFILE\Downloads\UGUI\UAssetGUI.exe"
    $candidates += "$env:USERPROFILE\Downloads\UAssetGUI.exe"

    $found = Get-ChildItem "$env:USERPROFILE\Downloads" -Recurse -Filter "UAssetGUI.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) { $candidates += $found.FullName }

    foreach ($c in $candidates) {
        if ($c -and (Test-Path $c)) { return (Resolve-Path $c).Path }
    }
    throw "UAssetGUI.exe not found. Pass -UAssetGUI path or put it in C:\Users\Cesar\Downloads\UGUI"
}


function Test-PythonCommand {
    param(
        [string]$Exe,
        [string[]]$Args = @()
    )
    try {
        $Output = & $Exe @Args --version 2>&1
        $Text = ($Output | Out-String)
        if ($LASTEXITCODE -eq 0 -and $Text -match "Python\s+3\.") {
            return $true
        }
    } catch {}
    return $false
}

function Find-Python {
    $Checks = @(
        @{ Name = "py"; Args = @("-3") },
        @{ Name = "python"; Args = @() },
        @{ Name = "python3"; Args = @() }
    )

    foreach ($Check in $Checks) {
        $Cmd = Get-Command $Check.Name -ErrorAction SilentlyContinue
        if (!$Cmd) { continue }
        $Exe = $Cmd.Source
        if (!$Exe) { $Exe = $Cmd.Path }
        if (!$Exe) { $Exe = $Check.Name }

        if (Test-PythonCommand -Exe $Exe -Args $Check.Args) {
            $Version = (& $Exe @($Check.Args) --version 2>&1 | Out-String).Trim()
            return [pscustomobject]@{
                Exe = $Exe
                Args = $Check.Args
                Display = ("{0} {1}" -f $Exe, ($Check.Args -join " ")).Trim()
                Version = $Version
            }
        }
    }

    throw @"
Python 3 was not found.

Install Python 3.10 or newer, then reopen this launcher.
During install, enable: Add python.exe to PATH.

Steam users still need Python because the minimap builder uses Python patch scripts before UnrealPak builds the pak.
"@
}

function Get-GamePaths {
    $GameExe = Find-DungeonsExe $PreferredGameExe
    $Win64Dir = Split-Path -Parent $GameExe
    $GameRoot = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $Win64Dir))
    $PakDir = Join-Path $GameRoot "Dungeons\Content\Paks"
    $ModsDir = Join-Path $Win64Dir "Mods"
    if (!(Test-Path $PakDir)) { throw "Paks folder not found: $PakDir" }
    return @{
        GameExe = $GameExe
        Win64Dir = $Win64Dir
        GameRoot = $GameRoot
        PakDir = $PakDir
        ModsDir = $ModsDir
        ModsTxt = (Join-Path $ModsDir "mods.txt")
    }
}

function Disable-NYXRuntime {
    param([string]$ModsTxt)
    if (Test-Path $ModsTxt) {
        $lines = Get-Content $ModsTxt -ErrorAction SilentlyContinue
        $lines = @($lines | Where-Object {
            $_ -notmatch '^\s*NYX_LiveMinimap\s*:' -and
            $_ -notmatch '^\s*NYX_MinimapGui\s*:'
        })
        $lines += "NYX_LiveMinimap : 0"
        $lines += "NYX_MinimapGui : 0"
        Set-Content $ModsTxt $lines -Encoding ASCII
    }
}

function Remove-OldNYXPaks {
    param([string]$PakDir)

    $patterns = @("zzz_NYX*.pak", "NYX*.pak", "*NYX*.pak")
    foreach ($pattern in $patterns) {
        Get-ChildItem $PakDir -File -Filter $pattern -ErrorAction SilentlyContinue |
            ForEach-Object {
                Write-Host "Removing old NYX pak: $($_.Name)"
                Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue
            }
    }

    Start-Sleep -Milliseconds 300

    $left = Get-ChildItem $PakDir -File -Filter "*NYX*.pak" -ErrorAction SilentlyContinue
    if ($left) {
        Write-Host "WARNING: some NYX paks are still present:" -ForegroundColor Yellow
        $left | Select-Object Name,FullName,Length,LastWriteTime | Format-Table -AutoSize
    }
}

function Stop-Dungeons {
    Stop-Process -Name "Dungeons" -Force -ErrorAction SilentlyContinue
    Stop-Process -Name "Dungeons-Win64-Shipping" -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 800
}

function Find-ExtractedAsset {
    param([string]$RelativePath, [string]$FileNameFallback)

    $paths = Get-GamePaths
    $paks = $paths.PakDir
    $candidates = @()

    # Public package fallback. These base assets are included so the tool does not
    # require a separate extracted game-asset folder before rebuilding.
    $PackageBaseAssets = Join-Path $PSScriptRoot "BaseAssets"
    if (Test-Path $PackageBaseAssets) {
        $candidates += (Join-Path $PackageBaseAssets $RelativePath)
    }

    $dirs = Get-ChildItem $paks -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match "^pakchunk.*WindowsNoEditor$" }
    foreach ($d in $dirs) {
        $candidates += (Join-Path $d.FullName $RelativePath)
    }

    $candidates += (Join-Path $env:USERPROFILE ("Downloads\NYX_MCD_COLLECTED_CANDIDATES\Candidates_Cooked\pakchunk4-WindowsNoEditor\" + $RelativePath))
    $candidates += (Join-Path $env:USERPROFILE ("Downloads\NYX_MCD_COLLECTED_CANDIDATES\Candidates_Cooked\pakchunk0-WindowsNoEditor\" + $RelativePath))

    foreach ($c in $candidates) {
        if ($c -and (Test-Path $c)) { return (Resolve-Path $c).Path }
    }

    $searchRoots = @()
    if (Test-Path $PackageBaseAssets) { $searchRoots += $PackageBaseAssets }
    $searchRoots += $dirs.FullName
    $collected = Join-Path $env:USERPROFILE "Downloads\NYX_MCD_COLLECTED_CANDIDATES\Candidates_Cooked"
    if (Test-Path $collected) { $searchRoots += $collected }

    foreach ($root in $searchRoots) {
        if ($root -and (Test-Path $root)) {
            $hit = Get-ChildItem $root -Recurse -File -Filter $FileNameFallback -ErrorAction SilentlyContinue |
                Select-Object -First 1
            if ($hit) { return $hit.FullName }
        }
    }

    throw "Could not find base asset: $RelativePath or $FileNameFallback. Extract the full release zip again and make sure the BaseAssets folder is still next to Open_Minimap_Modder.bat."
}

function Build-PakFromStage {
    param([string]$StageRoot, [string]$PakOut)

    $UnrealPak = Find-UnrealPak
    New-Item -ItemType Directory -Force (Split-Path $PakOut -Parent) | Out-Null

    $PakList = Join-Path (Split-Path $PakOut -Parent) ((Split-Path $PakOut -Leaf) + ".txt")
    $lines = New-Object System.Collections.Generic.List[string]

    Get-ChildItem $StageRoot -Recurse -File | Sort-Object FullName | ForEach-Object {
        $rel = $_.FullName.Substring($StageRoot.Length).TrimStart('\').Replace('\','/')
        $mount = "../../../$rel"
        $lines.Add('"' + $_.FullName + '" "' + $mount + '"')
    }

    Set-Content $PakList $lines -Encoding ASCII

    Write-Host "Using UnrealPak: $UnrealPak"
    & $UnrealPak $PakOut "-Create=$PakList" -compress
    if (!(Test-Path $PakOut)) { throw "Pak build failed: $PakOut" }
}
